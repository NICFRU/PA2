/*******************************************
***
***
*** Author:	Niclas Cramer
*** Date:	  21 Jun 2022 17:07:04
***
*** Source:	C:\Users\Niclas\Development\Tool\v.20.06.2022\processed\BKPF_192021.txt_processed
*** Dest.:	[DU00545_Worx_SRC].import.BKPF_192021
***
*** Topic:	Automatically generated import script.
***
***
*******************************************/

use [DU00545_Worx_SRC]
go

/******************************************/
/*** Create import schema			    	    ***/
/******************************************/

IF NOT EXISTS(select 1 from INFORMATION_SCHEMA.SCHEMATA where SCHEMA_NAME = 'import')
BEGIN
    exec('create schema import')
END

/******************************************/
/*** Create table and insert data	    	***/
/******************************************/

IF OBJECT_ID('import.BKPF_192021','U') IS NOT NULL
drop table import.BKPF_192021
go

create table import.BKPF_192021(
      [CoCd] nvarchar(255)
     ,[DocumentNo] nvarchar(255)
     ,[Year] nvarchar(255)
     ,[Type] nvarchar(255)
     ,[Doc. Date] nvarchar(255)
     ,[Pstng Date] nvarchar(255)
     ,[Period] nvarchar(255)
     ,[Entry Date] nvarchar(255)
     ,[Time] nvarchar(255)
     ,[Changed] nvarchar(255)
     ,[Last updte] nvarchar(255)
     ,[TranslDate] nvarchar(255)
     ,[User Name] nvarchar(255)
     ,[TCode] nvarchar(255)
     ,[Crss-CC no] nvarchar(255)
     ,[Reference] nvarchar(255)
     ,[RecEnt doc] nvarchar(255)
     ,[Rev. with] nvarchar(255)
     ,[Year.1] nvarchar(255)
     ,[Document Header Text] nvarchar(255)
     ,[Crcy] nvarchar(255)
     ,[Exch.rate] nvarchar(255)
     ,[GrpCy] nvarchar(255)
     ,[Group exch.rate] nvarchar(255)
     ,[S] nvarchar(255)
     ,[Net document type] nvarchar(255)
     ,[Un.del.cts] nvarchar(255)
     ,[I] nvarchar(255)
     ,[Tran] nvarchar(255)
     ,[Sess. Name] nvarchar(255)
     ,[Document name] nvarchar(255)
     ,[ExtractID] nvarchar(255)
     ,[DT] nvarchar(255)
     ,[Ref. Tran.] nvarchar(255)
     ,[Reference Key] nvarchar(255)
     ,[FMA] nvarchar(255)
     ,[LCurr] nvarchar(255)
     ,[LCur2] nvarchar(255)
     ,[LCur3] nvarchar(255)
     ,[Ex.rate 2] nvarchar(255)
     ,[Ex.rate 3] nvarchar(255)
     ,[SC] nvarchar(255)
     ,[SC.1] nvarchar(255)
     ,[Tr.date] nvarchar(255)
     ,[Tr.date.1] nvarchar(255)
     ,[Reversal flag] nvarchar(255)
     ,[Revers.Dte] nvarchar(255)
     ,[Calc.tax] nvarchar(255)
     ,[CT] nvarchar(255)
     ,[CT.1] nvarchar(255)
     ,[ERTy] nvarchar(255)
     ,[ERTy.1] nvarchar(255)
     ,[Net entry] nvarchar(255)
     ,[SCCd] nvarchar(255)
     ,[Tax detail] nvarchar(255)
     ,[Status] nvarchar(255)
     ,[Log.System] nvarchar(255)
     ,[Rte txs] nvarchar(255)
     ,[Request No] nvarchar(255)
     ,[B/ex.bf.due dte] nvarchar(255)
     ,[Reason] nvarchar(255)
     ,[Parked by] nvarchar(255)
     ,[Branch no.] nvarchar(255)
     ,[Pages] nvarchar(255)
     ,[dis. doc.] nvarchar(255)
     ,[Ref.key 1] nvarchar(255)
     ,[Ref.key 2] nvarchar(255)
     ,[Reversal] nvarchar(255)
     ,[IR date] nvarchar(255)
     ,[Ld] nvarchar(255)
     ,[Ledger Grp] nvarchar(255)
     ,[Mand.] nvarchar(255)
     ,[Alt Refer] nvarchar(255)
     ,[Rep. Date] nvarchar(255)
     ,[Doc.Type] nvarchar(255)
     ,[Split] nvarchar(255)
     ,[RT] nvarchar(255)
     ,[Reason.1] nvarchar(255)
     ,[Region] nvarchar(255)
     ,[S.1] nvarchar(255)
     ,[File no.] nvarchar(255)
     ,[IF] nvarchar(255)
     ,[Int.rt.dte] nvarchar(255)
     ,[Postng Day] nvarchar(255)
     ,[Act] nvarchar(255)
     ,[Chngd] nvarchar(255)
     ,[Time    .1] nvarchar(255)
     ,[A] nvarchar(255)
     ,[CTyp] nvarchar(255)
     ,[Card no.] nvarchar(255)
     ,[Block] nvarchar(255)
     ,[Lot] nvarchar(255)
     ,[User] nvarchar(255)
     ,[Sampled] nvarchar(255)
     ,[Exc.Ind] nvarchar(255)
     ,[BL Ind.] nvarchar(255)
     ,[OffsetStat] nvarchar(255)
     ,[Refer.Date] nvarchar(255)
     ,[LR] nvarchar(255)
)
go

--insert the data
BULK INSERT import.BKPF_192021
    FROM 'C:\Users\Niclas\Development\Tool\v.20.06.2022\processed\BKPF_192021.txt_processed'
    WITH
    (
        FIRSTROW = 2,
        MAXERRORS = 0,			--no errors allowed
        FIELDTERMINATOR = '|',
        ROWTERMINATOR = '0x0D000A00',
        CODEPAGE = 1252,
        BATCHSIZE = 1000000
    )
go

/******************************************/
/*** Control totals / Quality checks	***/
/******************************************/

select COUNT(1) from import.BKPF_192021
--
--expected: "273628"

select top 10 * from import.BKPF_192021
--

--The next line checks for exact duplicates, can take a long time!
select count(1) from (select distinct * from import.BKPF_192021) temp
--

--Remember to check the primary key! Sorry, the script didn't know the primary key
select distinct [KEY_COLUMNS] from import.BKPF_192021
--

select distinct top 20 ltrim(rtrim([CoCd])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([DocumentNo])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Year])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Type])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Doc. Date])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Pstng Date])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Period])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Entry Date])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Time])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Changed])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Last updte])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([TranslDate])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([User Name])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([TCode])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Crss-CC no])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Reference])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([RecEnt doc])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Rev. with])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Year.1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Document Header Text])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Crcy])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Exch.rate])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([GrpCy])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Group exch.rate])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([S])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Net document type])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Un.del.cts])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([I])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Tran])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Sess. Name])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Document name])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([ExtractID])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([DT])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Ref. Tran.])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Reference Key])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([FMA])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([LCurr])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([LCur2])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([LCur3])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Ex.rate 2])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Ex.rate 3])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([SC])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([SC.1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Tr.date])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Tr.date.1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Reversal flag])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Revers.Dte])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Calc.tax])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([CT])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([CT.1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([ERTy])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([ERTy.1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Net entry])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([SCCd])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Tax detail])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Status])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Log.System])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Rte txs])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Request No])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([B/ex.bf.due dte])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Reason])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Parked by])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Branch no.])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Pages])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([dis. doc.])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Ref.key 1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Ref.key 2])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Reversal])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([IR date])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Ld])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Ledger Grp])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Mand.])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Alt Refer])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Rep. Date])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Doc.Type])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Split])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([RT])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Reason.1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Region])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([S.1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([File no.])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([IF])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Int.rt.dte])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Postng Day])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Act])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Chngd])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Time    .1])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([A])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([CTyp])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Card no.])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Block])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Lot])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([User])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Sampled])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Exc.Ind])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([BL Ind.])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([OffsetStat])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([Refer.Date])) from import.BKPF_192021         --
select distinct top 20 ltrim(rtrim([LR])) from import.BKPF_192021         --



/******************************************/
/*** Create prepare schema				***/
/******************************************/

IF NOT EXISTS(select 1 from INFORMATION_SCHEMA.SCHEMATA where SCHEMA_NAME = 'transform')
BEGIN
	exec('create schema transform')
END

/******************************************/
/*** Prepare the data					***/
/******************************************/

IF OBJECT_ID('transform.BKPF_192021','U') IS NOT NULL
drop table transform.BKPF_192021
go

select
	   ltrim(rtrim([CoCd])) as [CoCd]
	  ,ltrim(rtrim([DocumentNo])) as [DocumentNo]
	  ,ltrim(rtrim([Year])) as [Year]
	  ,ltrim(rtrim([Type])) as [Type]
	  ,ltrim(rtrim([Doc. Date])) as [Doc. Date]
	  ,ltrim(rtrim([Pstng Date])) as [Pstng Date]
	  ,ltrim(rtrim([Period])) as [Period]
	  ,ltrim(rtrim([Entry Date])) as [Entry Date]
	  ,ltrim(rtrim([Time])) as [Time]
	  ,ltrim(rtrim([Changed])) as [Changed]
	  ,ltrim(rtrim([Last updte])) as [Last updte]
	  ,ltrim(rtrim([TranslDate])) as [TranslDate]
	  ,ltrim(rtrim([User Name])) as [User Name]
	  ,ltrim(rtrim([TCode])) as [TCode]
	  ,ltrim(rtrim([Crss-CC no])) as [Crss-CC no]
	  ,ltrim(rtrim([Reference])) as [Reference]
	  ,ltrim(rtrim([RecEnt doc])) as [RecEnt doc]
	  ,ltrim(rtrim([Rev. with])) as [Rev. with]
	  ,ltrim(rtrim([Year.1])) as [Year.1]
	  ,ltrim(rtrim([Document Header Text])) as [Document Header Text]
	  ,ltrim(rtrim([Crcy])) as [Crcy]
	  ,ltrim(rtrim([Exch.rate])) as [Exch.rate]
	  ,ltrim(rtrim([GrpCy])) as [GrpCy]
	  ,ltrim(rtrim([Group exch.rate])) as [Group exch.rate]
	  ,ltrim(rtrim([S])) as [S]
	  ,ltrim(rtrim([Net document type])) as [Net document type]
	  ,ltrim(rtrim([Un.del.cts])) as [Un.del.cts]
	  ,ltrim(rtrim([I])) as [I]
	  ,ltrim(rtrim([Tran])) as [Tran]
	  ,ltrim(rtrim([Sess. Name])) as [Sess. Name]
	  ,ltrim(rtrim([Document name])) as [Document name]
	  ,ltrim(rtrim([ExtractID])) as [ExtractID]
	  ,ltrim(rtrim([DT])) as [DT]
	  ,ltrim(rtrim([Ref. Tran.])) as [Ref. Tran.]
	  ,ltrim(rtrim([Reference Key])) as [Reference Key]
	  ,ltrim(rtrim([FMA])) as [FMA]
	  ,ltrim(rtrim([LCurr])) as [LCurr]
	  ,ltrim(rtrim([LCur2])) as [LCur2]
	  ,ltrim(rtrim([LCur3])) as [LCur3]
	  ,ltrim(rtrim([Ex.rate 2])) as [Ex.rate 2]
	  ,ltrim(rtrim([Ex.rate 3])) as [Ex.rate 3]
	  ,ltrim(rtrim([SC])) as [SC]
	  ,ltrim(rtrim([SC.1])) as [SC.1]
	  ,ltrim(rtrim([Tr.date])) as [Tr.date]
	  ,ltrim(rtrim([Tr.date.1])) as [Tr.date.1]
	  ,ltrim(rtrim([Reversal flag])) as [Reversal flag]
	  ,ltrim(rtrim([Revers.Dte])) as [Revers.Dte]
	  ,ltrim(rtrim([Calc.tax])) as [Calc.tax]
	  ,ltrim(rtrim([CT])) as [CT]
	  ,ltrim(rtrim([CT.1])) as [CT.1]
	  ,ltrim(rtrim([ERTy])) as [ERTy]
	  ,ltrim(rtrim([ERTy.1])) as [ERTy.1]
	  ,ltrim(rtrim([Net entry])) as [Net entry]
	  ,ltrim(rtrim([SCCd])) as [SCCd]
	  ,ltrim(rtrim([Tax detail])) as [Tax detail]
	  ,ltrim(rtrim([Status])) as [Status]
	  ,ltrim(rtrim([Log.System])) as [Log.System]
	  ,ltrim(rtrim([Rte txs])) as [Rte txs]
	  ,ltrim(rtrim([Request No])) as [Request No]
	  ,ltrim(rtrim([B/ex.bf.due dte])) as [B/ex.bf.due dte]
	  ,ltrim(rtrim([Reason])) as [Reason]
	  ,ltrim(rtrim([Parked by])) as [Parked by]
	  ,ltrim(rtrim([Branch no.])) as [Branch no.]
	  ,ltrim(rtrim([Pages])) as [Pages]
	  ,ltrim(rtrim([dis. doc.])) as [dis. doc.]
	  ,ltrim(rtrim([Ref.key 1])) as [Ref.key 1]
	  ,ltrim(rtrim([Ref.key 2])) as [Ref.key 2]
	  ,ltrim(rtrim([Reversal])) as [Reversal]
	  ,ltrim(rtrim([IR date])) as [IR date]
	  ,ltrim(rtrim([Ld])) as [Ld]
	  ,ltrim(rtrim([Ledger Grp])) as [Ledger Grp]
	  ,ltrim(rtrim([Mand.])) as [Mand.]
	  ,ltrim(rtrim([Alt Refer])) as [Alt Refer]
	  ,ltrim(rtrim([Rep. Date])) as [Rep. Date]
	  ,ltrim(rtrim([Doc.Type])) as [Doc.Type]
	  ,ltrim(rtrim([Split])) as [Split]
	  ,ltrim(rtrim([RT])) as [RT]
	  ,ltrim(rtrim([Reason.1])) as [Reason.1]
	  ,ltrim(rtrim([Region])) as [Region]
	  ,ltrim(rtrim([S.1])) as [S.1]
	  ,ltrim(rtrim([File no.])) as [File no.]
	  ,ltrim(rtrim([IF])) as [IF]
	  ,ltrim(rtrim([Int.rt.dte])) as [Int.rt.dte]
	  ,ltrim(rtrim([Postng Day])) as [Postng Day]
	  ,ltrim(rtrim([Act])) as [Act]
	  ,ltrim(rtrim([Chngd])) as [Chngd]
	  ,ltrim(rtrim([Time    .1])) as [Time    .1]
	  ,ltrim(rtrim([A])) as [A]
	  ,ltrim(rtrim([CTyp])) as [CTyp]
	  ,ltrim(rtrim([Card no.])) as [Card no.]
	  ,ltrim(rtrim([Block])) as [Block]
	  ,ltrim(rtrim([Lot])) as [Lot]
	  ,ltrim(rtrim([User])) as [User]
	  ,ltrim(rtrim([Sampled])) as [Sampled]
	  ,ltrim(rtrim([Exc.Ind])) as [Exc.Ind]
	  ,ltrim(rtrim([BL Ind.])) as [BL Ind.]
	  ,ltrim(rtrim([OffsetStat])) as [OffsetStat]
	  ,ltrim(rtrim([Refer.Date])) as [Refer.Date]
	  ,ltrim(rtrim([LR])) as [LR]

    into transform.BKPF_192021
    from import.BKPF_192021
go

select count(1) from transform.BKPF_192021
--

select top 10 * from transform.BKPF_192021
--

